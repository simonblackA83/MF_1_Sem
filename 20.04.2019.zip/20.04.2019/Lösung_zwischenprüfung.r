# Aufgabe 1


# a. Nicht station?re da a_1=2 (>1 im Betrag)

#b. Station?r da Eigenwerte AR(2) kleiner 1
abs(polyroot(c(0.9,-1.2,1)))
A_mat<-rbind(c(1.2,-0.9),c(1,0))
abs(eigen(A_mat)$values)

# c. MA immer station?r

# c. Nicht-station?r da Erwartungswert t ist (?ndert sich also mit Zeit t)

# d. Nicht station?r da Varianz t^2 sigma^2 ist (also von t abh?ngt)




#-----------------------------

# Aufgabe 2



path.dat<-"C:\\wia_desktop\\2020\\Unterricht\\Eco1\\abgeben\\14.04.2019\\"
#write.table(series,file=paste(path.dat,"series.txt",sep=""))

series<-read.table(paste(path.dat,"series.txt",sep=""))#,header=T, na.strings = "NA")

x<-series[,4]
par(mfrow=c(2,1))
acf(x,lag.max=25)
acf(x,type="partial")

# 1
maorder<-2
arorder<-1

# 2
maorder<-12
arorder<-0

# 3
maorder<-0
arorder<-4

# 4
maorder<-0
arorder<-4 # einfacher aber Diagnosen nicht optimal
arorder<-8 # komplex aber Diagnosen etwas besser
# Alternative ARMA
maorder<-2
arorder<-4 




y.arma<-arima(x,order=c(arorder,0,maorder))
# bei Ordnung 12 ist Ljung-Box noch immer nicht i.O. (man m?sste AR-Ordnung 20 w?hlen)
tsdiag(y.arma,gof.lag=25)
# Prognosen : Punkt-+Intervallprognosen
y.fore<-predict(y.arma,n.ahead=20)
ts.plot(x,y.fore$pred)#,y.fore$pred-2*y.fore$se,y.fore$pred+2*y.fore$se,lty=1:3)
abline(h=0)



#----------------------------
# Aufgabe 3



wic<-read.table(paste(path.dat,"wic.txt",sep=""),header=T)
ts.plot(wic[,2])
acf(wic[,2])

x<-wic[,2]

ts.plot(x)
par(mfrow=c(2,1))
acf(x)
acf(x,type="partial")

x_obj<-arima(x,order=c(4,0,0))
tsdiag(x_obj)

predict(x_obj,n.ahead=2)

predict(x_obj,n.ahead=2)$se^2

predict(x_obj,n.ahead=2)$pred-1.96*predict(x_obj,n.ahead=2)$se

#-----------------------------------------
# Aufgabe 4

mu=100

Var=(1+0.5^2)*0.1


B_mat<--0.5



# Suchen Gewichte von X_T und X_T-1 (k?nnen mu=0 annehmen)
#epsilon_t=x_t-0.5x_{t-1}+0.5^2x_{t-2}-0.5^3epsilon_{t-3}

#Gewichte: 0.5, -0.5^2
# Restterm: 0.5^3epsilon_{t-3} (klein)