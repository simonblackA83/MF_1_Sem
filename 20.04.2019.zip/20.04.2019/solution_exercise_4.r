# Series 4

# Exercise 1.a
sigma<-1
a_vec<-c(1.6,-1.4,0.5)
# Specify the system-matrix A_mat
A_mat<-matrix(ncol=length(a_vec),nrow=length(a_vec))
A_mat[1,]<-a_vec
A_mat[2:length(a_vec),1:(length(a_vec)-1)]<-diag(rep(1,length(a_vec)-1))
A_mat[2:length(a_vec),length(a_vec)]<-0
A_mat

AkA<-kronecker(A_mat,A_mat)
AkA
vec_sigma<-c(sigma^2,rep(0,dim(AkA)[2]-1))
vec_sigma
# Ricatti equation
R_mat_0_vec<-solve(diag(rep(1,dim(AkA)[2]))-AkA)%*%vec_sigma
R_mat_0<-matrix(R_mat_0_vec,ncol=dim(A_mat)[2])
R_mat_0

len_R<-100
R_mat_k<-R_mat_0
R_k<-rep(0,len_R)
for (i in 0:(len_R-1))
{
  R_k[i+1]<-R_mat_k[1,1]
  R_mat_k<-A_mat%*%R_mat_k
}

# Exercise 1.b

len<-100000
x<-arima.sim(n=len,list(ar=a_vec))

# Exercise 1.c

acf_true<-R_k/R_mat_0[1,1]

ts.plot(acf(x,plot=F,lag.max=100)$acf,xlab="",ylab="")
lines(acf_true,col="blue")
lines(rep(2/sqrt(len),len),lty=2)
lines(rep(-2/sqrt(len),len),lty=2)
lines(rep(0,len))
mtext("Sample acf", side = 3, line = -1,at=length(acf(x,plot=F)$acf)/2,col="black")
mtext("True acf", side = 3, line = -2,at=length(acf(x,plot=F)$acf)/2,col="blue")

# Exercise 1.d

# We observe a damped cycle

#----------------------------------------------------------------------
# Exercise 2

# Exercise 2.a
# The impulse response corresponds to the weights of the MA-inversion
# We use the code of exercise 1.d in previous Series 3 of exercises

A_rec<-diag(rep(1,length(a_vec)))

len_ma_inv<-100
# a_weight collects the weights (1,1)-elements of A_mat^k
a_weight<-A_rec[1,1]

for (i in 1:len_ma_inv) #i<-2
{

# We compute A_mat^k
  A_rec<-A_rec%*%A_mat
# and store the weight of the MA-inversion
  a_weight<-c(a_weight,A_rec[1,1])
}

ts.plot(a_weight)

# Exercise 2.b-2.c

eigen(A_mat)$values

# We have two cycles with duration:

2*pi/Arg(eigen(A_mat)$values)

# Rate of decay (persistency) : abolute eigenvalues

abs(eigen(A_mat)$values)

# The cycle with duration/periodicity T=6.30887 has a stronger persistency:
# Therefore it is better visible in the impulse response plot.


# Exercise 2.d

ts.plot(a_weight)
#The dampled cycle in the impulse response lasts~6 time units as expected.

# Exercise 2.e


ts.plot(a_weight,xlab="",ylab="")
lines(acf_true,col="blue")
lines(rep(2/sqrt(len),len),lty=2)
lines(rep(-2/sqrt(len),len),lty=2)
lines(rep(0,len))
mtext("Impulse response", side = 3, line = -1,at=length(acf(x,plot=F)$acf)/2,col="black")
mtext("True acf", side = 3, line = -2,at=length(acf(x,plot=F)$acf)/2,col="blue")


# For better comparison we shift and normalize the impulse response

ts.plot(a_weight[2:len_ma_inv]/a_weight[2],xlab="",ylab="")
lines(acf_true,col="blue")
lines(rep(2/sqrt(len),len),lty=2)
lines(rep(-2/sqrt(len),len),lty=2)
lines(rep(0,len))
mtext("Impulse response", side = 3, line = -1,at=length(acf(x,plot=F)$acf)/2,col="black")
mtext("True acf", side = 3, line = -2,at=length(acf(x,plot=F)$acf)/2,col="blue")

# As expected one can see a close correspondence between both functions:
# both functions are based on the AR(2)-equation and both eliminate the
# random disturbances by the white noise.



#------------------------------------------------------------------------
# Exercise 3

# Specification as in exercise 1 above
a_vec<-c(1.6,-1.4,0.5)


# Exercise 3.a
mu<-6/(1-sum(a_vec))
set.seed(10)
len<-100
x<-mu+arima.sim(n=len,list(ar=a_vec))

# Exercise 3.b
par(mfrow=c(2,1))
acf(x)
acf(x,type="partial")
# p=3 seems to be a reasonable choice
p<-3


# Exercise 3.c

y_ar<-arima(x,order=c(p,0,0))
#y_ar$sigma
tsdiag(y_ar)

a_for<-y_ar$coef[1:p]
mu_hat<-y_ar$coef[p+1]
c<-mu_hat*(1-sum(a_for))

# Exercise 3.d

A_mat_hat<-matrix(ncol=length(a_for),nrow=length(a_for))
A_mat_hat[1,]<-a_for
A_mat_hat[2:length(a_for),1:(length(a_for)-1)]<-diag(rep(1,length(a_for)-1))
A_mat_hat[2:length(a_for),length(a_for)]<-0
A_mat_hat

abs(eigen(A_mat_hat)$values)


# Exerecise 3.e

h<-100
x_for_mu<-x_for_intercept<-x[(len-p+1):len]
for (i in 1:h)
{
# Formel mit mu
  x_for_mu<-c(x_for_mu,a_for%*%(x_for_mu[length(x_for_mu):(length(x_for_mu)-p+1)]-mu_hat)+mu_hat)
# Formel mit intercept (in slides)
  x_for_intercept<-c(x_for_intercept,c+a_for%*%(x_for_intercept[length(x_for_intercept):(length(x_for_intercept)-p+1)]))
}

# Beide Formelausdr�cke sind �quivalent
cbind(x_for_mu,x_for_intercept)

x_for_h<-x_for_intercept[p+1:h]
ts.plot(x_for_h)



# Exercise 3.f

A_rec_hat<-diag(rep(1,length(a_for)))

len_ma_inv<-h
# a_weight collects the weights (1,1)-elements of A_mat^k
a_weight_hat<-A_rec_hat[1,1]

for (i in 1:len_ma_inv) #i<-2
{
  A_rec_hat<-A_rec_hat%*%A_mat_hat
  a_weight_hat<-c(a_weight_hat,A_rec_hat[1,1])
}

ts.plot(a_weight_hat)


# Exercise 3.g
sigma_hat<-sqrt(y_ar$sigma)
x_var_h<-rep(0,h)
for (i in 1:h)
  x_var_h[i]<-sigma_hat^2*sum(a_weight_hat[1:i]^2)

var(x)
x_var_h[h]
#R_mat_0[1,1]

# Exercise 3.h

x_for_h
predict(y_ar,n.ahead=h)$pred
x_var_h
predict(y_ar,n.ahead=h)$se^2

# Exercise 3.i

ts.plot(c(x,rep(NA,h)),xlab="",ylab="")
lines(c(rep(0,len),x_for_h),col="blue")
lines(c(rep(0,len),x_for_h-2*sqrt(x_var_h)),lty=2,col="blue")
lines(c(rep(0,len),x_for_h+2*sqrt(x_var_h)),lty=2,col="blue")

# Exercise 3.j
# The point forecast as well as the impulse function show the true AR-structure (damped-cycles)
# because both assume that `future' noise is zero. However, the point forecast is initialized
# with the latest data whereas the impulse response is initialized with a singular unity impulse.


# Exercise 3.k


AkA_hat<-kronecker(A_mat_hat,A_mat_hat)
vec_sigma_hat<-c(sigma_hat^2,rep(0,dim(AkA_hat)[2]-1))
# Ricatti equation
R_mat_0_vec_hat<-solve(diag(rep(1,dim(AkA_hat)[2]))-AkA_hat)%*%vec_sigma_hat
R_mat_0_hat<-matrix(R_mat_0_vec_hat,ncol=dim(A_mat_hat)[2])

sqrt(R_mat_0_hat[1,1])
sqrt(x_var_h[h])
# Both standard deviations are identical, as expected

x_for_h[h]
mu_hat<-y_ar$coef[p+1]
mu_hat

# Convergence of point forecast to the estimated mean-level mu_hat is virtually achieved



#----------------------------------------------------------------------------
# Exercise 4
# In sample vs. out-sample
set.seed(10)
len<-100
x<-arima.sim(n=len,list(ar=a_vec))

par(mfrow=c(2,1))
acf(x)
acf(x,type="partial")

# First series looks like a AR(3): diagnostics of AR(4) are OK

y_ar<-arima(x,order=c(3,0,0))
tsdiag(y_ar)

# Diagnostics for an MA(6) are still a bit limit
y_ma<-arima(x,order=c(0,0,6))
tsdiag(y_ma)

# out-of-sample
simanz<-200
h<-10
forecast_error_ma_out<-matrix(nrow=h,ncol=simanz)
forecast_error_ar_out<-forecast_error_ma_out
forecast_error_ar6_out<-forecast_error_ma_out
set.seed(10)

for (i in 1:simanz)        #i<-1
{
  x<-arima.sim(list(ar=a_vec),n=len+h)
  y_ma<-arima(x[1:len],order=c(0,0,6))
  y_ar<-arima(x[1:len],order=c(3,0,0))
  y_ar6<-arima(x[1:len],order=c(6,0,0))
  forecast_error_ma_out[,i]<-(predict(y_ma,n.ahead=h)$pred-x[(len+1):(len+h)])^2
  forecast_error_ar_out[,i]<-(predict(y_ar,n.ahead=h)$pred-x[(len+1):(len+h)])^2
  forecast_error_ar6_out[,i]<-(predict(y_ar6,n.ahead=h)$pred-x[(len+1):(len+h)])^2
  print(i)
}

out_of_sample<-cbind(apply(forecast_error_ma_out,1,mean),apply(forecast_error_ar_out,1,mean),apply(forecast_error_ar6_out,1,mean))
ts.plot(out_of_sample[,1],xlab="Forecast horizon",ylab="MSFE",main="Out-of-sample")
lines(out_of_sample[,2],col="blue")
lines(out_of_sample[,3],col="red")
mtext("MA(6)", side = 3, line = -1,at=h/2,col="black")
mtext("AR(3)", side = 3, line = -2,at=h/2,col="blue")
mtext("AR(6)", side = 3, line = -3,at=h/2,col="red")



# in sample
simanz<-200
h<-10
forecast_error_ma_in<-matrix(nrow=h,ncol=simanz)
forecast_error_ar_in<-forecast_error_ma_in
forecast_error_ar6_in<-forecast_error_ma_in
set.seed(10)

for (i in 1:simanz)        #i<-1
{
  x<-arima.sim(list(ar=a_vec),n=len+h)
  y_ma<-arima(x,order=c(0,0,6))
  y_ar<-arima(x,order=c(3,0,0))
  y_ar6<-arima(x,order=c(6,0,0))


  forecast_error_ma_in[,i]<-(predict(y_ma,n.ahead=h)$pred-x[(len+1):(len+h)])^2
  forecast_error_ar_in[,i]<-(predict(y_ar,n.ahead=h)$pred-x[(len+1):(len+h)])^2
  forecast_error_ar6_in[,i]<-(predict(y_ar6,n.ahead=h)$pred-x[(len+1):(len+h)])^2
  print(i)
}

in_sample<-cbind(apply(forecast_error_ma_in,1,mean),apply(forecast_error_ar_in,1,mean),apply(forecast_error_ar6_in,1,mean))
ts.plot(in_sample[,1],xlab="Forecast horizon",ylab="MSFE",main="In-sample")
lines(in_sample[,2],col="blue")
lines(in_sample[,3],col="red")
mtext("MA(6)", side = 3, line = -1,at=h/2,col="black")
mtext("AR(3)", side = 3, line = -2,at=h/2,col="blue")
mtext("AR(6)", side = 3, line = -3,at=h/2,col="red")

y_ma$x
