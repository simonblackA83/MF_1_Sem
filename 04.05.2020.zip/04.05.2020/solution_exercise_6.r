# Exercise Series 6



# Exercise 1.a


# Zur Erinnerung: dies waren die (von hand) identifizierten Modellordnungen aus ?bung 5
#   Wir ?berpr?fen hier ob AIC und/oder BIC diese Modellordnungen erkennen


# 1
arorder<-1
maorder<-1


# 2
arorder<-2
maorder<-1


# 3
arorder<-1
maorder<-2




y_data<-read.table("C:\\wia_desktop\\2020\\Unterricht\\Eco1\\abgeben\\04.05.2020\\y_data_exercise5.txt")




y<-y_data[,3]
ts.plot(y)
len<-length(y)

par(mfrow=c(2,1))
acf(y)
acf(y,type="partial")



maxarorder<-5
maxmaorder<-5
sigma_jk<-matrix(rep(0,(maxmaorder+1)*(maxarorder+1)),
ncol=maxmaorder+1,nrow=maxarorder+1)
# Order (zero,zero)
sigma_jk[1,1]<-var(y)
for (j in 0:maxarorder)
{
  for (k in 0:maxmaorder)         #k<-4  j<-4
  {
    ARMA_obj<-arima(y,order=c(j,0,k))
    sigma_jk[j+1,k+1]<-ARMA_obj$sigma
#    print(paste("  AR-order=",j,"MA-Order=",k,"  AIC=",ARMA_obj$aic,sep=""))
  }
}
log_sigma_jk<-log(sigma_jk)
aic<-sigma_jk
dimnames(aic)[[2]]<-paste("MA-order",0:maxmaorder,sep=" ")
dimnames(aic)[[1]]<-paste("AR-order",0:maxarorder,sep=" ")
bic<-aic
for (j in 0:maxarorder)
{
  for (k in 0:maxmaorder)
  {
    aic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+2*(j+k)/len
    bic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+log(len)*(j+k)/len
  }
}
aic
bic

which(aic == min(aic), arr.ind = TRUE) 
which(bic == min(bic), arr.ind = TRUE) 

# Model orders
which(aic == min(aic), arr.ind = TRUE)-1 
which(bic == min(bic), arr.ind = TRUE)-1 


# Diagnostics
arorder<-1
maorder<-2
y_obj<-arima(y,order=c(arorder,0,maorder))

tsdiag(y_obj)


#------------------------------------------------------------------------
# Exercise 2

# a)
len<-100
a_1<-0.9
b_1<-0.9
A_mat<-rbind(c(a_1,1),c(0,0))
B_mat<-rbind(c(-b_1,1),c(0,0))
A_mat
B_mat
len<-100
A_k<-diag(rep(1,2))
B_k<-A_k
a_vec<-c(1,-a_1)
b_vec<-c(1,b_1)
AR_weights<-1:len
MA_weights<-AR_weights
for (i in 1:len)
{
  AR_weights[i]<-(B_k%*%a_vec)[1]
  MA_weights[i]<-(A_k%*%b_vec)[1]
  A_k<-A_k%*%A_mat
  B_k<-B_k%*%B_mat
}
ts.plot(AR_weights,col="red",xlab="",ylab="",main="AR- and MA-inversions of ARMA(1,1)",ylim=c(-1,1))
lines(MA_weights,col="blue")
mtext("MA-inversion", side = 3, line = -1,at=len/2,col="blue")
mtext("AR_inversion", side = 3, line = -2,at=len/2,col="red")

# b)
# Sum of first 12 squared MA-weights exceeds 90% of variance of process
sum(MA_weights[1:12]^2)/sum(MA_weights^2)

# c)
# The arithmetic mean is likely to perform well if h>12

#-------------------------------------------------------------------------------------



recession_data<-read.table("D:\\wia_desktop\\2019\\Unterricht\\Eco1\\Exercises\\Data\\recession_data.txt")

x<-recession_data[,1]
ts.plot(x)

# a)
arorder<-2
maorder<-1

x_obj<-arima(x,order=c(arorder,0,maorder))


tsdiag(x_obj)



x_pred<-predict(x_obj,n.ahead=30)

# 90% intervals!!!!
quant<-1.6

ymin<-min(x_pred$pred-quant*x_pred$se)
ymax<-max(x_pred$pred+quant*x_pred$se)

ts.plot(c(x,x_pred$pred),ylim=c(ymin,ymax))
lines(c(x,x_pred$pred+quant*x_pred$se))
lines(c(x,x_pred$pred-quant*x_pred$se))
abline(h=0)

# b) The point forecast has its minimum (dip) in t=120. The point forecast is positive in t=139


# c)
# The upper 90%-interval dips in t=117; the lower interval dips in t=125

