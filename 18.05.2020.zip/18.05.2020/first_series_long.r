

#---------------------------------------
# Weekly data: 1-26 steps ahead (see excel spreadsheet)


# Daten einlesen
Pfad<-getwd()

xdat<-read.table(paste(Pfad,"/first_long.txt",sep=""),header=T)

# Spalte ausw?hlen: ohne NA's und als Zeitreihe
x<-as.ts(na.exclude(xdat))
len<-length(x)

# Plot
ts.plot(x[1:81])
ts.plot(x)



# Monatsdaten: m?gliche Saisonl?nge 12
xdiff<-diff(x,lag=12)

ts.plot(xdiff)






#---------------------
# SARIMA-Modellierung : verschiedene Modelle m?glich (auf Differenzen achten)
# 1. M?glichkeit: mit Originaldaten
acf(x,lag.max=25)
acf(x,lag.max=25,type="partial")

# Zu einfach
fit <- arima(x, include.mean=FALSE, order=c(0,0,0), method="ML",seasonal=list(order=c(0,1,1),period=12))



# Diagnosen OK
fit <- arima(x, include.mean=FALSE, order=c(1,0,2), method="ML",seasonal=list(order=c(1,0,1),period=12))
fit <- arima(x, include.mean=FALSE, order=c(1,0,2), method="ML",seasonal=list(order=c(0,1,1),period=12))
fit <- arima(x, include.mean=FALSE, order=c(0,1,2), method="ML",seasonal=list(order=c(0,1,1),period=12))

fit

tsdiag(fit,gof.lag=53)

y.for<-predict(fit,n.ahead=18)

ts.plot(x,y.for$pred)
abline(v=length(x))

































