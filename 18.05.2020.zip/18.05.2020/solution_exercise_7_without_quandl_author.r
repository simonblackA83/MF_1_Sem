rm(list = ls())



# Older data set: ends in 2016
indpro<-read.table(paste(getwd(),"/indpro_2016.txt",sep=""))
# This data set is hit by covid break-out
indpro<-read.table(paste(getwd(),"/indpro_covid.txt",sep=""))

ts.plot(indpro)

# Gewöhnliches Matrix-Objekt
y<-as.matrix(indpro)
len<-length(y)


par(mfrow=c(2,1))
acf(y)
acf(y,type="partial")

#--------------------------------------------
# Exercise 1: Stationary Model
# Forecast converges towards mean (BIG RECESSION....)
d<-0
maxarorder<-5
maxmaorder<-5
sigma_jk<-matrix(rep(0,(maxmaorder+1)*(maxarorder+1)),
                 ncol=maxmaorder+1,nrow=maxarorder+1)
# Order (zero,zero)
sigma_jk[1,1]<-var(y)
for (j in 0:maxarorder)
{
  
  for (k in 0:maxmaorder)         #k<-3  j<-4
  {
    # Avoid interrupt if optimization fails    
    try_obj<-try(arima(y,order=c(j,d,k)),silent=T)
    if (is.character(try_obj[1]))
    {
      # If interrupted: sigma is set to a large value (`bad' model)      
      sigma_jk[j+1,k+1]<-1.e+99      
    } else
    {
      ARMA_obj<-arima(y,order=c(j,d,k))
      print(c(j,k))
      sigma_jk[j+1,k+1]<-ARMA_obj$sigma
      print(paste("  AR-order=",j,"MA-Order=",k,"  AIC=",ARMA_obj$aic,sep=""))      
    }
  }
}

len<-length(y)
log_sigma_jk<-log(sigma_jk)
aic<-sigma_jk
dimnames(aic)[[2]]<-paste("MA-order",0:maxmaorder,sep=" ")
dimnames(aic)[[1]]<-paste("AR-order",0:maxarorder,sep=" ")
bic<-aic
for (j in 0:maxarorder)
{
  for (k in 0:maxmaorder)
  {
    aic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+2*(j+k)/len
    bic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+log(len)*(j+k)/len
  }
}
aic
bic
which(aic == min(aic), arr.ind = TRUE)-1 
which(bic == min(bic), arr.ind = TRUE)-1 
arorder<-which(bic == min(bic), arr.ind = TRUE)[1]-1 
maorder<-which(bic == min(bic), arr.ind = TRUE)[2]-1 

# Numerical optimization difficult for `big' models: ARMA(2,2) seems OK according to available BICs




y_obj<-arima(y,order=c(arorder,d,maorder))

tsdiag(y_obj)


# One step 

y_pred<-predict(y_obj,n.ahead=1)

ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))


# 100 step: converges to 'mean' and intervals converge to +/- 2*sigma
y_pred<-predict(y_obj,n.ahead=100)

ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))




#--------------------------------------------
# Exercise 2: I(1) Model
# Stays on a higher level than mean
d<-1
maxarorder<-5
maxmaorder<-5
sigma_jk<-matrix(rep(0,(maxmaorder+1)*(maxarorder+1)),
                 ncol=maxmaorder+1,nrow=maxarorder+1)
# Order (zero,zero)
sigma_jk[1,1]<-var(y)
for (j in 0:maxarorder)
{
  
  for (k in 0:maxmaorder)         #k<-4  j<-3
  {
    # Avoid interrupt if optimization fails    
    try_obj<-try(arima(y,order=c(j,d,k)),silent=T)
    if (is.character(try_obj[1]))
    {
      # If interrupted: sigma is set to a large value (`bad' model)      
      sigma_jk[j+1,k+1]<-1.e+99      
    } else
    {
      ARMA_obj<-arima(y,order=c(j,d,k))
      print(c(j,k))
      sigma_jk[j+1,k+1]<-ARMA_obj$sigma
      print(paste("  AR-order=",j,"MA-Order=",k,"  AIC=",ARMA_obj$aic,sep=""))      
    }
  }
}
len<-length(y)
log_sigma_jk<-log(sigma_jk)
aic<-sigma_jk
dimnames(aic)[[2]]<-paste("MA-order",0:maxmaorder,sep=" ")
dimnames(aic)[[1]]<-paste("AR-order",0:maxarorder,sep=" ")
bic<-aic
for (j in 0:maxarorder)#j<-5  k<-4
{
  for (k in 0:maxmaorder)
  {
    aic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+2*(j+k)/len
    bic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+log(len)*(j+k)/len
  }
}
aic
bic
which(aic == min(aic), arr.ind = TRUE)-1 
which(bic == min(bic), arr.ind = TRUE)-1 







arorder<-which(bic == min(bic), arr.ind = TRUE)[1]-1 
maorder<-which(bic == min(bic), arr.ind = TRUE)[2]-1 

y_obj<-arima(y,order=c(arorder,d,maorder))

tsdiag(y_obj)

ts.plot(y)

# One step (similar to above)

y_pred<-predict(y_obj,n.ahead=1)

ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))


# 100 step: flattens out at a level larger than 'mean' (for indpro_2016 at least...), large intervals (too large...)
y_pred<-predict(y_obj,n.ahead=100)

ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))



#--------------------------------------------
# Exercise 3: I(2) Model
d<-2
maxarorder<-5
maxmaorder<-5
sigma_jk<-matrix(rep(0,(maxmaorder+1)*(maxarorder+1)),
                 ncol=maxmaorder+1,nrow=maxarorder+1)
# Order (zero,zero)
sigma_jk[1,1]<-var(y)
for (j in 0:maxarorder)
{
  
  for (k in 0:maxmaorder)         #k<-4  j<-3
  {
    # Avoid interrupt if optimization fails    
    try_obj<-try(arima(y,order=c(j,d,k)),silent=T)
    if (is.character(try_obj[1]))
    {
      # If interrupted: sigma is set to a large value (`bad' model)      
      sigma_jk[j+1,k+1]<-1.e+99      
    } else
    {
      ARMA_obj<-arima(y,order=c(j,d,k))
      print(c(j,k))
      sigma_jk[j+1,k+1]<-ARMA_obj$sigma
      print(paste("  AR-order=",j,"MA-Order=",k,"  AIC=",ARMA_obj$aic,sep=""))      
    }
  }
}
len<-length(y)
log_sigma_jk<-log(sigma_jk)
aic<-sigma_jk
dimnames(aic)[[2]]<-paste("MA-order",0:maxmaorder,sep=" ")
dimnames(aic)[[1]]<-paste("AR-order",0:maxarorder,sep=" ")
bic<-aic
for (j in 0:maxarorder)
{
  for (k in 0:maxmaorder)
  {
    aic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+2*(j+k)/len
    bic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+log(len)*(j+k)/len
  }
}
aic
bic
which(aic == min(aic), arr.ind = TRUE)-1 
which(bic == min(bic), arr.ind = TRUE)-1 







arorder<-which(bic == min(bic), arr.ind = TRUE)[1]-1 
maorder<-which(bic == min(bic), arr.ind = TRUE)[2]-1 

y_obj<-arima(y,order=c(arorder,d,maorder))
#!!!!!!!!!!!!!!!!! Huge outliers!!!!!!!!
#   This can impact all statistics (including BIC)!!!!!
tsdiag(y_obj)


# One step (similar to above I(1)-model)

y_pred<-predict(y_obj,n.ahead=1)

ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))


# 100 step: ARMA(0,2,2) is selected by BIC and long-term forecast is trending down with huge/spreading intervals
y_pred<-predict(y_obj,n.ahead=100)

ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))




#-------------------------------------------------------
# Summary
# One-step ahead forecasts of I(0), I(1) and I(2) models are similar; differences can be seen at longer forecast horizons 
# The main problem (for indpro_2016) is the great recession; for indpro_covid there is even more severe problem/collapse: 
#     Avoid having such singular events in the estimation span!!!
# Multi-step:
#   -I(0): Stationary model: forecast converges to mean +/- 2*sigma (problematic if series is non-stationary)
#   -I(1): forecast flattens out at a level which is not the mean; intervals open up (too) rapidly
#   -I(2): forecast is generally trending (does not flatten) and intervals spread out much too rapidly 
#   -Economic series are in general much more predictable than suggested by I(2)-models 











#############################################################################################
#--------------------------------------------------------------------------------------------
# S&P 
# Log und diff
# Random-walk
# GARCH-Effekte (Prognoseintervalle zu breit)

sp_all<-read.table(paste(getwd(),"/sp_all_2016.txt",sep=""))
sp_all<-read.table(paste(getwd(),"/sp_all_covid.txt",sep=""))
tail(sp_all)


class(sp_all)
head(sp_all)

sp<-as.matrix(sp_all[,1])

# Compare the covid-sample with/without log-transformation!
ts.plot(sp)
ts.plot(log(sp))

# Mit logs arbeiten (Finanzdaten: log-returns stabilisieren Varianz und Niveau)
#   Remove NAs
y<-log(na.exclude(sp))
len<-length(y)

par(mfrow=c(2,1))
acf(y)
acf(y,type="partial")

#--------------------------------------------
# Exercise 1: Stationary Model
# AR-polynomial has a unit-root (first differences)
d<-0
maxarorder<-4
maxmaorder<-4
sigma_jk<-matrix(rep(0,(maxmaorder+1)*(maxarorder+1)),
                 ncol=maxmaorder+1,nrow=maxarorder+1)
# Order (zero,zero)
for (j in 0:maxarorder)
{
  
  for (k in 0:maxmaorder)         #k<-4  j<-3
  {
    # Avoid interrupt if optimization fails    
    try_obj<-try(arima(y,order=c(j,d,k)),silent=T)
    if (is.character(try_obj[1]))
    {
      # If interrupted: sigma is set to a large value (`bad' model)      
      sigma_jk[j+1,k+1]<-1.e+99      
    } else
    {
      ARMA_obj<-arima(y,order=c(j,d,k))
      print(c(j,k))
      sigma_jk[j+1,k+1]<-ARMA_obj$sigma
      print(paste("  AR-order=",j,"MA-Order=",k,"  AIC=",ARMA_obj$aic,sep=""))      
    }
  }
}
len<-length(y)
log_sigma_jk<-log(sigma_jk)
aic<-sigma_jk
dimnames(aic)[[2]]<-paste("MA-order",0:maxmaorder,sep=" ")
dimnames(aic)[[1]]<-paste("AR-order",0:maxarorder,sep=" ")
bic<-aic
for (j in 0:maxarorder)
{
  for (k in 0:maxmaorder)
  {
    aic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+2*(j+k)/len
    bic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+log(len)*(j+k)/len
  }
}
aic
bic
which(aic == min(aic), arr.ind = TRUE)-1 
which(bic == min(bic), arr.ind = TRUE)-1 





arorder<-which(bic == min(bic), arr.ind = TRUE)[1]-1 
maorder<-which(bic == min(bic), arr.ind = TRUE)[2]-1 


y_obj<-arima(y,order=c(arorder,d,maorder))

# Unit-root: stationary model is nearly non-stationary! Series needs a difference
y_obj$coef
# Charakteristisches Polynom: einer der Eigenwerte der A-matrix ist fast 1: suggeriert erste Differenzen
abs(polyroot(c(-y_obj$coef[arorder:1],1)))
# MA is invertible
abs(polyroot(c(y_obj$coef[arorder+maorder:1],1)))


# Vola-clustering in residuals: ARCH/GARCH-models (OEKO2)
tsdiag(y_obj)

ts.plot(y)


# Short-term forecasts (1-10 steps ahead) pretty close to random-walk model!!!!!!!!!!!!!
y_pred<-predict(y_obj,n.ahead=300)

ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))



# Forecasts converge very slowly to mean +/- 2*sigma (model nearly non-stationary)
y_pred<-predict(y_obj,n.ahead=30000)

ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))









#--------------------------------------------
# Exercise 2: I(1) Model
# Random-walk
d<-1
maxarorder<-4
maxmaorder<-4
sigma_jk<-matrix(rep(0,(maxmaorder+1)*(maxarorder+1)),
                 ncol=maxmaorder+1,nrow=maxarorder+1)
len<-length(y)
# Order (zero,zero)
sigma_jk[1,1]<-var(y)
for (j in 0:maxarorder)
{
  
  for (k in 0:maxmaorder)         #k<-4  j<-3
  {
    # Avoid interruption if optimization fails    
    try_obj<-try(arima(y,order=c(j,d,k)),silent=T)
    if (is.character(try_obj[1]))
    {
      # If interrupted: sigma is set to a large value (`bad' model)      
      sigma_jk[j+1,k+1]<-1.e+99      
    } else
    {
      ARMA_obj<-arima(y,order=c(j,d,k))
      print(c(j,k))
      sigma_jk[j+1,k+1]<-ARMA_obj$sigma
      print(paste("  AR-order=",j,"MA-Order=",k,"  AIC=",ARMA_obj$aic,sep=""))      
    }
  }
}
len<-length(y)
log_sigma_jk<-log(sigma_jk)
aic<-sigma_jk
dimnames(aic)[[2]]<-paste("MA-order",0:maxmaorder,sep=" ")
dimnames(aic)[[1]]<-paste("AR-order",0:maxarorder,sep=" ")
bic<-aic
for (j in 0:maxarorder)
{
  for (k in 0:maxmaorder)
  {
    aic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+2*(j+k)/len
    bic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+log(len)*(j+k)/len
  }
}
aic
bic
which(aic == min(aic), arr.ind = TRUE)-1 
which(bic == min(bic), arr.ind = TRUE)-1 







arorder<-which(bic == min(bic), arr.ind = TRUE)[1]-1 
maorder<-which(bic == min(bic), arr.ind = TRUE)[2]-1 

y_obj<-arima(y,order=c(arorder,d,maorder))


#################################################################
# Analyse für Modell aufgrund von covid Reihe (Daten bis und mit Mai 2020)
if (rownames(sp_all)[nrow(sp_all)]=="2020-05-12")
{  
  # Charakteristisches Polynom: Eigenwerte der A-matrix nahe 1: doppelte Diffs?
  abs(polyroot(c(-y_obj$coef[arorder:1],1)))
  # MA is invertible
  abs(polyroot(c(y_obj$coef[arorder+maorder:1],1)))
  # The two AR- and MA-roots near 1 cancel each other (they were probably retained by BIC because of data-problems: vola-cluster)
  # After simplification a better model might be the following:
  y_obj_better<-arima(y,order=c(1,d,1))
  tsdiag(y_obj_better)
  
  # Unit-root: stationary model is nearly non-stationary! Series needs a difference
  y_obj_better$coef
  # After inspection AR- and MA- are pretty close so finally an even 'better' model might be
  y_obj_even_better<-arima(y,order=c(1,d,0))
  # Unit-root: stationary model is nearly non-stationary! Series needs a difference
  y_obj_even_better
  # Or
  y_obj_even_better<-arima(y,order=c(0,d,1))
  # Unit-root: stationary model is nearly non-stationary! Series needs a difference
  y_obj_even_better
  # Note that both models are very close to random-walk, as expected (efficient markets)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
}
##################################################################

# Vola-cluster (vgl. OEKO2)
# Möglicher Tageseffekt bei lag 5 (Ljung/Box signifikant)
#   Evtl. saisonales Modell testen (mit Saisonlänge 5)
tsdiag(y_obj)

ts.plot(y)

y_pred<-predict(y_obj,n.ahead=300)

ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

# Forecast pretty close to random-walk model!!!!!!!!!!!!!
ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))


y_pred<-predict(y_obj,n.ahead=30000)

ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

# Forecast pretty close to random-walk model!!!!!!!!!!!!!
ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))




#--------------------------------------------
# Exercise 3: I(2) Model
# One of the roots of MA-polynomial cancels second difference
d<-2
maxarorder<-4
maxmaorder<-4
sigma_jk<-matrix(rep(0,(maxmaorder+1)*(maxarorder+1)),
                 ncol=maxmaorder+1,nrow=maxarorder+1)
# Order (zero,zero)
for (j in 0:maxarorder)
{
  
  for (k in 0:maxmaorder)         #k<-4  j<-3
  {
    # Avoid interrupt if optimization fails    
    try_obj<-try(arima(y,order=c(j,d,k)),silent=T)
    if (is.character(try_obj[1]))
    {
      # If interrupted: sigma is set to a large value (`bad' model)      
      sigma_jk[j+1,k+1]<-1.e+99      
    } else
    {
      ARMA_obj<-arima(y,order=c(j,d,k))
      print(c(j,k))
      sigma_jk[j+1,k+1]<-ARMA_obj$sigma
      print(paste("  AR-order=",j,"MA-Order=",k,"  AIC=",ARMA_obj$aic,sep=""))      
    }
  }
}
len<-length(y)
log_sigma_jk<-log(sigma_jk)
aic<-sigma_jk
dimnames(aic)[[2]]<-paste("MA-order",0:maxmaorder,sep=" ")
dimnames(aic)[[1]]<-paste("AR-order",0:maxarorder,sep=" ")
bic<-aic
for (j in 0:maxarorder)
{
  for (k in 0:maxmaorder)
  {
    aic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+2*(j+k)/len
    bic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+log(len)*(j+k)/len
  }
}
aic
bic
which(aic == min(aic), arr.ind = TRUE)-1 
which(bic == min(bic), arr.ind = TRUE)-1 







arorder<-which(bic == min(bic), arr.ind = TRUE)[1]-1 
maorder<-which(bic == min(bic), arr.ind = TRUE)[2]-1 

y_obj<-arima(y,order=c(arorder,d,maorder))

# MA-non-invertible i.e. model is random-walk
y_obj

#################################################################
# Analyse für Modell aufgrund von covid Reihe (Daten bis und mit Mai 2020)
if (rownames(sp_all)[nrow(sp_all)]=="2020-05-12")
{  
  # MA is nearly invertible: cancels one of the differences. The AR-parameters are close to 0 i.e. nearly random walk...
  y_obj$coef
  abs(polyroot(c(-y_obj$coef[arorder:1],1)))
  # One of the MA-roots is nearly 1 (cancels one of the differences)
  abs(polyroot(c(y_obj$coef[arorder+maorder:1],1)))
  # After simplification a better model might be the following I(1) (single differences)
  y_obj_better<-arima(y,order=c(0,1,2))
  tsdiag(y_obj_better)
  
  # Note that both models are very close to random-walk, as expected (efficient markets)!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
}
##################################################################



tsdiag(y_obj)

ts.plot(y)

y_pred<-predict(y_obj,n.ahead=300)


ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

# Short term forecast (1-10-steps) is close to random-walk
# For sp_covid data-set the forecast trends up because of recovery (it would trend down during the heavy draw-down period)
ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))



y_pred<-predict(y_obj,n.ahead=30000)


ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

# Short term forecast (1-10-steps) is close to random-walk
# For sp_covid data-set the forecast trends up because of recovery (it would trend down during the heavy draw-down period)
ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))




#------------
# Summary findings
# All models suggest random-walk after simplification of AR- and MA-roots (fundamental Hypothesis financial markets)
#   Stationary: one of the AR_roots is almost one i.e. close to random-walk 
#   I(1): model is close to random-walk (0,1,0)  
#   I(2): non invertible MA-root cancels the second order difference i.e. model close to random-walk
# All forecasts are close to random-walk at short forecast horizons
#   At long horizons stationary model converges to mean, I(1) flattens out and I(2) keeps trending, as expected









#############################################################################################
#--------------------------------------------------------------------------------------------
# GDP 

gdp<-read.table(paste(getwd(),"/gdp.txt",sep=""))


ts.plot(gdp)
class(gdp)

# data.frame in matrix umwandeln (evtl. mit logs arbeiten)
y<-as.matrix(gdp)
len<-length(y)

par(mfrow=c(2,1))
acf(y)
acf(y,type="partial")

#--------------------------------------------
# Exercise 1: Stationary Model
# Numerical algorithm breaks down (therefore maxorders=2)
# AR(1)=1
d<-0
maxarorder<-5
maxmaorder<-5
sigma_jk<-matrix(rep(0,(maxmaorder+1)*(maxarorder+1)),
                 ncol=maxmaorder+1,nrow=maxarorder+1)
# Order (zero,zero)
sigma_jk[1,1]<-var(y)
for (j in 0:maxarorder)
{
  
  for (k in 0:maxmaorder)         #k<-4  j<-3
  {
    # Avoid interrupt if optimization fails    
    try_obj<-try(arima(y,order=c(j,d,k)),silent=T)
    if (is.character(try_obj[1]))
    {
      # If interrupted: sigma is set to a large value (`bad' model)      
      sigma_jk[j+1,k+1]<-1.e+99      
    } else
    {
      ARMA_obj<-arima(y,order=c(j,d,k))
      print(c(j,k))
      sigma_jk[j+1,k+1]<-ARMA_obj$sigma
      print(paste("  AR-order=",j,"MA-Order=",k,"  AIC=",ARMA_obj$aic,sep=""))      
    }
  }
}
len<-length(y)
log_sigma_jk<-log(sigma_jk)
aic<-sigma_jk
dimnames(aic)[[2]]<-paste("MA-order",0:maxmaorder,sep=" ")
dimnames(aic)[[1]]<-paste("AR-order",0:maxarorder,sep=" ")
bic<-aic
for (j in 0:maxarorder)
{
  for (k in 0:maxmaorder)
  {
    aic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+2*(j+k)/len
    bic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+log(len)*(j+k)/len
  }
}
aic
bic
which(aic == min(aic), arr.ind = TRUE)-1 
which(bic == min(bic), arr.ind = TRUE)-1 






arorder<-which(bic == min(bic), arr.ind = TRUE)[1]-1 
maorder<-which(bic == min(bic), arr.ind = TRUE)[2]-1 

y_obj<-arima(y,order=c(arorder,d,maorder))

# Both roots of the characteristic AR(2)-polynomial are close to one: the series must be differenced (maybe twice)...
abs(polyroot(c(-y_obj$coef[2:1],1)))

tsdiag(y_obj)

ts.plot(y)

y_pred<-predict(y_obj,n.ahead=30)



ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))





#--------------------------------------------
# Exercise 2: I(1) Model
# Random-walk
d<-1
maxarorder<-5
maxmaorder<-5
sigma_jk<-matrix(rep(0,(maxmaorder+1)*(maxarorder+1)),
                 ncol=maxmaorder+1,nrow=maxarorder+1)
# Order (zero,zero)
sigma_jk[1,1]<-var(y)
for (j in 0:maxarorder)
{
  
  for (k in 0:maxmaorder)         #k<-4  j<-3
  {
    # Avoid interrupt if optimization fails    
    try_obj<-try(arima(y,order=c(j,d,k)),silent=T)
    if (is.character(try_obj[1]))
    {
      # If interrupted: sigma is set to a large value (`bad' model)      
      sigma_jk[j+1,k+1]<-1.e+99      
    } else
    {
      ARMA_obj<-arima(y,order=c(j,d,k))
      print(c(j,k))
      sigma_jk[j+1,k+1]<-ARMA_obj$sigma
      print(paste("  AR-order=",j,"MA-Order=",k,"  AIC=",ARMA_obj$aic,sep=""))      
    }
  }
}
len<-length(y)
log_sigma_jk<-log(sigma_jk)
aic<-sigma_jk
dimnames(aic)[[2]]<-paste("MA-order",0:maxmaorder,sep=" ")
dimnames(aic)[[1]]<-paste("AR-order",0:maxarorder,sep=" ")
bic<-aic
for (j in 0:maxarorder)
{
  for (k in 0:maxmaorder)
  {
    aic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+2*(j+k)/len
    bic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+log(len)*(j+k)/len
  }
}
aic
bic
which(aic == min(aic), arr.ind = TRUE)-1 
which(bic == min(bic), arr.ind = TRUE)-1 







arorder<-which(bic == min(bic), arr.ind = TRUE)[1]-1 
maorder<-which(bic == min(bic), arr.ind = TRUE)[2]-1 

y_obj<-arima(y,order=c(arorder,d,maorder))

# AR-root is close to one: suggests possibly second-order difference
y_obj

tsdiag(y_obj)

ts.plot(y)

y_pred<-predict(y_obj,n.ahead=30)

ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))



#--------------------------------------------
# Exercise 3: I(2) Model
# MA(1)=-1: hebt 2.Differenz auf
d<-2
maxarorder<-5
maxmaorder<-5
sigma_jk<-matrix(rep(0,(maxmaorder+1)*(maxarorder+1)),
                 ncol=maxmaorder+1,nrow=maxarorder+1)
# Order (zero,zero)
sigma_jk[1,1]<-var(y)
for (j in 0:maxarorder)
{
  
  for (k in 0:maxmaorder)         #k<-4  j<-3
  {
    # Avoid interrupt if optimization fails    
    try_obj<-try(arima(y,order=c(j,d,k)),silent=T)
    if (is.character(try_obj[1]))
    {
      # If interrupted: sigma is set to a large value (`bad' model)      
      sigma_jk[j+1,k+1]<-1.e+99      
    } else
    {
      ARMA_obj<-arima(y,order=c(j,d,k))
      print(c(j,k))
      sigma_jk[j+1,k+1]<-ARMA_obj$sigma
      print(paste("  AR-order=",j,"MA-Order=",k,"  AIC=",ARMA_obj$aic,sep=""))      
    }
  }
}
len<-length(y)
log_sigma_jk<-log(sigma_jk)
aic<-sigma_jk
dimnames(aic)[[2]]<-paste("MA-order",0:maxmaorder,sep=" ")
dimnames(aic)[[1]]<-paste("AR-order",0:maxarorder,sep=" ")
bic<-aic
for (j in 0:maxarorder)
{
  for (k in 0:maxmaorder)
  {
    aic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+2*(j+k)/len
    bic[j+1,k+1]<-log_sigma_jk[j+1,k+1]+log(len)*(j+k)/len
  }
}
aic
bic
which(aic == min(aic), arr.ind = TRUE)-1 
which(bic == min(bic), arr.ind = TRUE)-1 







arorder<-which(bic == min(bic), arr.ind = TRUE)[1]-1 
maorder<-which(bic == min(bic), arr.ind = TRUE)[2]-1 

y_obj<-arima(y,order=c(arorder,d,maorder))

tsdiag(y_obj)

ts.plot(y)

ymin<-min(c(as.vector(y),y_pred$pred-2*y_pred$se))
ymax<-max(c(as.vector(y),y_pred$pred+2*y_pred$se))

ts.plot(c(as.vector(y),y_pred$pred),ylim=c(ymin,ymax))
abline(v=length(y))
lines(c(as.vector(y),y_pred$pred+2*y_pred$se))
lines(c(as.vector(y),y_pred$pred-2*y_pred$se))

#----------------------------
# Summary findings
# Stationary model has a root near one (unit-root): suggest differences
# I(1) is ~OK 
# I(2) model : MA cancels second order difference: therefore forecasts are nearly the same as I(1)
# Note that all long-term predictions are questionable because they flatten out, as expected by I(1)-models 
#   (recall that I(2) becomes I(1))

