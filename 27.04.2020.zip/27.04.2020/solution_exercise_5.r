# Series 5



# Exercise 1.a
sigma<-1
a_vec<-c(1,-1.6,0.9)


6/(sum(a_vec))

# Exercise 1.b
b_vec<-c(1,-0.3,0.4)
# Specify the system-matrices A_mat and B_mat
A_mat<-matrix(ncol=length(a_vec),nrow=length(a_vec))
A_mat[,1]<-c(-a_vec[2:3],0)
A_mat[1:(length(a_vec)-1),2:length(a_vec)]<-
  diag(rep(1,length(a_vec)-1))
A_mat[length(a_vec),2:length(a_vec)]<-0
A_mat

B_mat<-matrix(ncol=length(b_vec),nrow=length(b_vec))
B_mat[,1]<-c(-b_vec[2:3],0)
B_mat[1:(length(b_vec)-1),2:length(b_vec)]<-diag(rep(1,length(b_vec)-1))
B_mat[length(b_vec),2:length(b_vec)]<-0
B_mat



# Check stationarity and Invertibility

abs(eigen(A_mat)$values)
abs(eigen(B_mat)$values)

# Exercise 1.c

len<-100
d_k<-rep(1:len)
A_k<-A_mat
for (i in 2:len)#i<-1
{
  d_k[i]<-(A_k%*%b_vec)[1]
  A_k<-A_k%*%A_mat
  
}

ts.plot(d_k)
# Check weights with function ARMAtoMA
ARMAtoMA(ar = -a_vec[2:3], ma = b_vec[2:3], lag.max=10)
d_k[1:10]

Rk<-1:11

for (i in 1:length(Rk))#i<-1
{
  Rk[i]<-d_k[i:len]%*%d_k[1:(len-i+1)]
}

Rk/Rk[1]
ARMAacf(ar = -a_vec[2:3], ma = b_vec[2:3], lag.max = 10, pacf = FALSE)
#----------------------------------------------------
# Exercise 2

# 1
arorder<-1
maorder<-1


# 2
arorder<-2
maorder<-1


# 3
arorder<-1
maorder<-2




y_data<-read.table("D:\\wia_desktop\\2019\\Unterricht\\Eco1\\Exercises\\Data\\y_data_exercise5.txt")
dim(y_data)
ts.plot(y_data)

x<-y_data[,3]

par(mfrow=c(2,1))
acf(x)
acf(x,type="partial")

arorder<-1
maorder<-2


x_obj<-arima(x,order=c(arorder,0,maorder))

tsdiag(x_obj)


#-------------------------------------------------------------------------------------
# Exercise 3

# 1. Beispiel
# Der Operator (1-0.5B) k�rzt sich auf beiden Seiten d.h. der Prozess ist
# x_t=C+epsilon_t
# Der Erwartungswert des Prozesses ist 2/(1-0.5)=4 d.h. C=4
# bzw. die Normalform lautet: X_t=4+epsilon_t

# 2. Beispiel
# Prozess ist bereits in Normalform


# 3. Beispiel
polyroot(c(0.2,-0.9,1))
# d.h. das Polynom ist (1-0.4B)(1-0.5B). Der Term 1-0.5B k�rzt sich auf beiden Seiten
# und es bleibt (1-0.4B)X_t=C+epsilon_t
# Das C wird wie folgt berechnet:
#  -Der Erwartungswert des Prozesses ist 2/(1-0.9+0.2)=6.666...
#  -C ist dann: C/(1-0.4)=6.666 bzw. C=4

# 4. Beispiel
polyroot(c(0.25,-1,1))
polyroot(c(0.1,-0.7,1))
# d.h. das AR-Polynom ist (1-0.5B)(1-0.5B) und das MA-Polynom ist
# (1-0.2B)(1-0.5B)
# Nach k�rzen von (1-0.5B) bleibt der ARMA(1,1) �brig:
# (1-0.5B)X_t=C+(1-0.2B)epsilon_t
# Dabei ergibt sich C wie folgt:
#  -der Erwartungswert des Prozesses ist  2/(1-1+0.25)=8
#  -Deshalb ist C/(1-0.5)=8 bzw. C=8*(1-0.5)=4







